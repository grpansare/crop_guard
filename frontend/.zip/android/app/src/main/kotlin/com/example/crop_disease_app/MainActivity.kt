package com.example.crop_disease_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
