import 'package:flutter/material.dart';
import 'package:crop_disease_app/services/auth_service.dart';

class ExpertDashboard extends StatefulWidget {
  const ExpertDashboard({super.key});

  @override
  State<ExpertDashboard> createState() => _ExpertDashboardState();
}

class _ExpertDashboardState extends State<ExpertDashboard> {
  Map<String, dynamic>? _userProfile;
  bool _isLoading = true;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _loadUserProfile();
  }

  Future<void> _loadUserProfile() async {
    try {
      final profile = await AuthService.getProfile();
      setState(() {
        _userProfile = profile;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Failed to load profile: ${e.toString().replaceAll('Exception: ', '')}';
        _isLoading = false;
      });
    }
  }

  Future<void> _handleLogout() async {
    await AuthService.logout();
    if (mounted) {
      Navigator.pushReplacementNamed(context, '/login');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Expert Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _handleLogout,
            tooltip: 'Logout',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _errorMessage.isNotEmpty
              ? Center(child: Text(_errorMessage, style: const TextStyle(color: Colors.red)))
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Welcome Card
                      Card(
                        elevation: 4,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.verified_user,
                                    color: Theme.of(context).primaryColor,
                                    size: 28,
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    'Welcome, Dr. ${_userProfile?['fullName'] ?? 'Expert'}!',
                                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                          fontWeight: FontWeight.bold,
                                          color: Theme.of(context).primaryColor,
                                        ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Mobile: ${_userProfile?['mobile'] ?? 'N/A'}',
                                style: Theme.of(context).textTheme.bodyLarge,
                              ),
                              const SizedBox(height: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(
                                  color: Colors.blue.shade100,
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  'Crop Disease Expert',
                                  style: TextStyle(
                                    color: Colors.blue.shade800,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      
                      // Expert Tools
                      Text(
                        'Expert Tools',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                      const SizedBox(height: 16),
                      GridView.count(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        crossAxisCount: 2,
                        crossAxisSpacing: 16,
                        mainAxisSpacing: 16,
                        children: [
                          _buildActionCard(
                            context,
                            icon: Icons.analytics,
                            label: 'Disease Analysis',
                            color: Colors.blue,
                            onTap: () {
                              // TODO: Implement disease analysis
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Disease Analysis feature coming soon!')),
                              );
                            },
                          ),
                          _buildActionCard(
                            context,
                            icon: Icons.assignment,
                            label: 'Review Cases',
                            color: Colors.orange,
                            onTap: () {
                              // TODO: Implement case review
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Case Review feature coming soon!')),
                              );
                            },
                          ),
                          _buildActionCard(
                            context,
                            icon: Icons.library_books,
                            label: 'Knowledge Base',
                            color: Colors.green,
                            onTap: () {
                              // TODO: Implement knowledge base
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Knowledge Base feature coming soon!')),
                              );
                            },
                          ),
                          _buildActionCard(
                            context,
                            icon: Icons.people,
                            label: 'Farmer Queries',
                            color: Colors.purple,
                            onTap: () {
                              // TODO: Implement farmer queries
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Farmer Queries feature coming soon!')),
                              );
                            },
                          ),
                          _buildActionCard(
                            context,
                            icon: Icons.trending_up,
                            label: 'Disease Trends',
                            color: Colors.red,
                            onTap: () {
                              // TODO: Implement disease trends
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Disease Trends feature coming soon!')),
                              );
                            },
                          ),
                          _buildActionCard(
                            context,
                            icon: Icons.settings,
                            label: 'Settings',
                            color: Colors.grey,
                            onTap: () {
                              // TODO: Implement settings
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Settings feature coming soon!')),
                              );
                            },
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),
                      
                      // Recent Expert Activity
                      Text(
                        'Recent Expert Activity',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                      const SizedBox(height: 16),
                      _buildExpertActivityList(),
                    ],
                  ),
                ),
    );
  }

  Widget _buildActionCard(
    BuildContext context, {
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 4,
                offset: Offset(0, 2),
              ),
            ],
          ),
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                width: 40,
                height: 40,
                child: Icon(icon, size: 30, color: color),
              ),
              const SizedBox(height: 8),
              Text(
                label,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildExpertActivityList() {
    // TODO: Replace with actual expert activities from API
    final activities = [
      {'title': 'Reviewed tomato blight case', 'time': '1 hour ago', 'type': 'review'},
      {'title': 'Updated disease database', 'time': '3 hours ago', 'type': 'update'},
      {'title': 'Responded to farmer query', 'time': '5 hours ago', 'type': 'response'},
      {'title': 'Analyzed disease trend data', 'time': '1 day ago', 'type': 'analysis'},
    ];

    if (activities.isEmpty) {
      return const Center(
        child: Text('No recent expert activities'),
      );
    }

    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: activities.length,
      itemBuilder: (context, index) {
        final activity = activities[index];
        IconData activityIcon;
        Color activityColor;
        
        switch (activity['type']) {
          case 'review':
            activityIcon = Icons.rate_review;
            activityColor = Colors.blue;
            break;
          case 'update':
            activityIcon = Icons.update;
            activityColor = Colors.green;
            break;
          case 'response':
            activityIcon = Icons.reply;
            activityColor = Colors.orange;
            break;
          case 'analysis':
            activityIcon = Icons.analytics;
            activityColor = Colors.purple;
            break;
          default:
            activityIcon = Icons.work;
            activityColor = Colors.grey;
        }
        
        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: Icon(activityIcon, color: activityColor),
            title: Text(activity['title'] ?? ''),
            subtitle: Text(activity['time'] ?? ''),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              // TODO: Handle activity tap
            },
          ),
        );
      },
    );
  }
}
