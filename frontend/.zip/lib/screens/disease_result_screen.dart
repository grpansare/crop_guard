import 'dart:io';
import 'package:flutter/material.dart';
import '../services/ml_service.dart';

class DiseaseResultScreen extends StatelessWidget {
  final File imageFile;
  final PredictionResult result;

  const DiseaseResultScreen({
    super.key,
    required this.imageFile,
    required this.result,
  });

  @override
  Widget build(BuildContext context) {
    final topPrediction = result.topPrediction;
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detection Results'),
        backgroundColor: Theme.of(context).primaryColor,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            onPressed: () => _shareResults(context),
            icon: const Icon(Icons.share),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Image Display
            Card(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  imageFile,
                  height: 250,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            
            const SizedBox(height: 16),
            
            // Main Result Card
            Card(
              color: _getResultColor(topPrediction.diseaseInfo.severity),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Icon(
                      _getResultIcon(result.isHealthy),
                      size: 48,
                      color: Colors.white,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      topPrediction.label,
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Confidence: ${topPrediction.confidencePercentage}',
                      style: const TextStyle(
                        fontSize: 18,
                        color: Colors.white70,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        'Severity: ${topPrediction.diseaseInfo.severity.displayName}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 16),
            
            // Disease Information
            if (!result.isHealthy) ...[
              _buildInfoCard(
                'Description',
                Icons.info_outline,
                topPrediction.diseaseInfo.description,
              ),
              
              _buildInfoCard(
                'Symptoms',
                Icons.warning_amber_outlined,
                '',
                items: topPrediction.diseaseInfo.symptoms,
              ),
              
              _buildInfoCard(
                'Treatment',
                Icons.medical_services_outlined,
                '',
                items: topPrediction.diseaseInfo.treatment,
              ),
              
              _buildInfoCard(
                'Prevention',
                Icons.shield_outlined,
                '',
                items: topPrediction.diseaseInfo.prevention,
              ),
            ] else ...[
              _buildInfoCard(
                'Plant Health',
                Icons.eco,
                topPrediction.diseaseInfo.description,
              ),
              
              _buildInfoCard(
                'Care Tips',
                Icons.lightbulb_outline,
                '',
                items: topPrediction.diseaseInfo.treatment,
              ),
            ],
            
            // Other Predictions
            if (result.predictions.length > 1) ...[
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Other Possibilities',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      ...result.predictions.skip(1).map((prediction) => 
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Text(
                                  prediction.label,
                                  style: const TextStyle(fontSize: 16),
                                ),
                              ),
                              Text(
                                prediction.confidencePercentage,
                                style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.grey.shade600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
            
            const SizedBox(height: 24),
            
            // Action Buttons
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.camera_alt),
                    label: const Text('Scan Another'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Theme.of(context).primaryColor,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _saveResults(context),
                    icon: const Icon(Icons.save),
                    label: const Text('Save Results'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 16),
            
            // Disclaimer
            Card(
              color: Colors.orange.shade50,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Row(
                  children: [
                    Icon(
                      Icons.warning_amber,
                      color: Colors.orange.shade700,
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'This is an AI prediction. For serious issues, consult an agricultural expert.',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.orange.shade700,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard(String title, IconData icon, String description, {List<String>? items}) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: Colors.blue.shade700),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue.shade700,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (description.isNotEmpty) ...[
              Text(
                description,
                style: const TextStyle(fontSize: 16),
              ),
            ],
            if (items != null && items.isNotEmpty) ...[
              ...items.map((item) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 2.0),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('• ', style: TextStyle(fontSize: 16)),
                    Expanded(
                      child: Text(
                        item,
                        style: const TextStyle(fontSize: 16),
                      ),
                    ),
                  ],
                ),
              )),
            ],
          ],
        ),
      ),
    );
  }

  Color _getResultColor(DiseaseSeverity severity) {
    switch (severity) {
      case DiseaseSeverity.none:
        return Colors.green;
      case DiseaseSeverity.low:
        return Colors.yellow.shade700;
      case DiseaseSeverity.medium:
        return Colors.orange;
      case DiseaseSeverity.high:
        return Colors.red;
    }
  }

  IconData _getResultIcon(bool isHealthy) {
    return isHealthy ? Icons.check_circle : Icons.warning;
  }

  void _shareResults(BuildContext context) {
    // TODO: Implement sharing functionality
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Share functionality coming soon!')),
    );
  }

  void _saveResults(BuildContext context) {
    // TODO: Implement save functionality
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Results saved successfully!')),
    );
  }
}
