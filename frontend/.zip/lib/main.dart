import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'screens/splash_screen.dart';
import 'screens/login_page.dart';
import 'screens/farmer_dashboard.dart';
import 'screens/expert_dashboard.dart';
import 'screens/scan_result_screen.dart';
import 'screens/test_api_screen.dart';
import 'screens/disease_detection_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CropDiseaseApp());
}

class CropDiseaseApp extends StatelessWidget {
  const CropDiseaseApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Reduce memory usage for graphics buffer (optional)
    SystemChannels.skia.invokeMethod('Skia.setResourceCacheMaxBytes', 1 << 20);

    return MaterialApp(
      title: 'Crop Disease ID',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.green,
        primaryColor: const Color(0xFF4CAF50),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF4CAF50),
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF4CAF50),
          foregroundColor: Colors.white,
          elevation: 0,
          centerTitle: true,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF4CAF50),
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            elevation: 2,
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.grey.shade400),
          ),
          focusedBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(12)),
            borderSide: BorderSide(color: Color(0xFF4CAF50), width: 2),
          ),
        ),
        cardTheme: ThemeData().cardTheme.copyWith(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      // Start with splash
      home: const SplashScreen(),
      routes: {
        '/login': (context) => const LoginPage(),
        '/dashboard': (context) => const FarmerDashboard(),
        '/expert-dashboard': (context) => const ExpertDashboard(),
        '/test-api': (context) => const TestApiScreen(),
        '/disease-detection': (context) => const DiseaseDetectionScreen(),
        '/scan-result': (context) {
          final args =
              ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>? ?? {};
          return ScanResultScreen(
            imagePath: args['imagePath'] ?? '',
            isGallery: args['isGallery'] ?? false,
          );
        },
      },
    );
  }
}
