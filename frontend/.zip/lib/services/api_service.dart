import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  // This is a hardcoded URL now, no longer using environment variables
  static const String baseUrl = 'http://192.168.0.103:8080/api';

  static const Duration timeoutDuration = Duration(seconds: 10);

  static Future<Map<String, String>> get headers async {
    return {
      'Content-Type': 'application/json; charset=UTF-8',
      'Accept': 'application/json',
    };
  }

  static Future<dynamic> post(
    String endpoint,
    Map<String, dynamic> body,
  ) async {
    try {
      // Debug: Print request details
      print('API Request: POST $baseUrl/$endpoint');
      print('Request Body: ${jsonEncode(body)}');

      final uri = Uri.parse('$baseUrl/$endpoint');
      print('Full URL: $uri');

      final response = await http
          .post(uri, headers: await headers, body: jsonEncode(body))
          .timeout(timeoutDuration);

      print('Response Status: ${response.statusCode}');
      print('Response Body: ${response.body}');

      return _handleResponse(response);
    } on http.ClientException catch (e) {
      print('HTTP Client Exception: $e');
      throw Exception('Network error: ${e.message}');
    } on FormatException catch (e) {
      print('Format Exception: $e');
      throw Exception('Invalid server response format');
    } catch (e) {
      print('Unexpected error in POST request: $e');
      rethrow;
    }
  }

  static Future<dynamic> getWithAuth(String endpoint, String token) async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl/$endpoint'),
            headers: {
              'Content-Type': 'application/json; charset=UTF-8',
              'Authorization': 'Bearer $token',
            },
          )
          .timeout(timeoutDuration);

      return _handleResponse(response);
    } catch (e) {
      throw Exception('Failed to make authenticated GET request: $e');
    }
  }

  static dynamic _handleResponse(http.Response response) {
    final responseBody = jsonDecode(response.body);

    if (response.statusCode >= 200 && response.statusCode < 300) {
      return responseBody;
    } else {
      throw Exception(
        responseBody['message'] ??
            'Request failed with status: ${response.statusCode}',
      );
    }
  }

  /// Tests the API connectivity by making a simple GET request to the base URL
  static Future<bool> testConnection() async {
    try {
      print('Testing API connection to: $baseUrl');
      final response = await http
          .get(Uri.parse(baseUrl))
          .timeout(const Duration(seconds: 5));
      print('API test response: ${response.statusCode}');
      return response.statusCode >= 200 && response.statusCode < 300;
    } catch (e) {
      print('API connection test failed: $e');
      return false;
    }
  }
}
