import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'api_service.dart';

class AuthService {
  static const _storage = FlutterSecureStorage();
  static const _tokenKey = 'auth_token';

  static Future<String?> getToken() async {
    return await _storage.read(key: _tokenKey);
  }

  static Future<void> setToken(String token) async {
    await _storage.write(key: _tokenKey, value: token);
  }

  static Future<void> deleteToken() async {
    await _storage.delete(key: _tokenKey);
  }

  static Future<Map<String, dynamic>> login(String mobile, String password) async {
    try {
      print('Sending login request for mobile: $mobile');
      
      final response = await ApiService.post('auth/signin', {
        'mobile': mobile,
        'password': password,
      });
      
      print('Login response received: $response');
      
      // Save the token if login is successful
      if (response['token'] != null) {
        await setToken(response['token']);
      } else {
        throw Exception('No token received from server');
      }
      
      return response;
    } catch (e) {
      rethrow;
    }
  }

  static Future<Map<String, dynamic>> register(String fullName, String mobile, String password, [String? role]) async {
    try {
      final requestData = {
        'fullName': fullName,
        'mobile': mobile,
        'password': password,
      };
      
      if (role != null && role.isNotEmpty) {
        requestData['role'] = role;
      }
      
      final response = await ApiService.post('auth/signup', requestData);
      
      return response;
    } catch (e) {
      rethrow;
    }
  }

  static Future<Map<String, dynamic>> getProfile() async {
    try {
      final token = await getToken();
      if (token == null) throw Exception('No token found');
      
      final response = await ApiService.getWithAuth('auth/profile', token);
      return response;
    } catch (e) {
      rethrow;
    }
  }

  static Future<void> logout() async {
    await deleteToken();
  }
}
